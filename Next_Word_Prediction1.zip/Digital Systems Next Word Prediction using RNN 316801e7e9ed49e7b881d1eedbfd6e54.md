# Digital Systems : Next Word Prediction using RNN

*Team Members :*

*Nimitt (22110169)*

*Siddharth Joshi (22110109)*

*Pratham Basant Sharda (22110203)*

*Anshul Mantri (22110143)*

## Weekly Plan

### Week 1

- Dataset Acquisition
- Preprocessing Functions : One Hot Encoding, Tokenensing,  Concatenating, etc.
- Activation Function Implementations : Sinusoid, Tanh and ReLU
- Optimised Matrix Multiplication
- Word Embeddings ( Tokens to Vectors ) using Feed Forward Neural Network

### Week 2

- Testing Word Embeddings Model
- LSTM cell Implementation
- LSTM Forward Propagation Implementation

### Week 3

- Parameter Training with Gradient Descent
- Output processing Functions : Conversion from Vectors to text etc.
- LSTM Backward Propagation Implementation
- Training over Dataset

### Week 4

- Hyperparameter Tuning
- Testing